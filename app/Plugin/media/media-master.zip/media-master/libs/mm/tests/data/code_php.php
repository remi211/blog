<?php

class ThisIsJust {

	function xyz() {

	}
}

?>